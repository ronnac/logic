(defproject reasoned-schemer "1.0.0-SNAPSHOT"
  :description "Reasoned Schemer in core.logic"
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [org.clojure/core.logic "0.7.5"]])
